^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package bad_changelog_pkg
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.5.77 (2013-10-09)
-------------------
* Contributors: Sömeöne with UTF-8 in their name
