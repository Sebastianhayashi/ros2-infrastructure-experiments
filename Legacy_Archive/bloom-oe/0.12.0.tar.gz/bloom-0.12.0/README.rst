bloom
=====

A tool for helping release software into gitbuildpackage repositories


Code & tickets
--------------

Build status: |Build Status|

.. image:: https://github.com/ros-infrastructure/bloom/actions/workflows/ci.yaml/badge.svg?branch=master&event=push
   :target: https://github.com/ros-infrastructure/bloom/actions/workflows/ci.yaml?query=branch%3Amaster+event%3Apush

+---------------+---------------------------------------------------+
| bloom         | http://ros.org/wiki/bloom                         |
+---------------+---------------------------------------------------+
| Issues        | http://github.com/ros-infrastructure/bloom/issues |
+---------------+---------------------------------------------------+
| Documentation | http://bloom.readthedocs.org                      |
+---------------+---------------------------------------------------+


